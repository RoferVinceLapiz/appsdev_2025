﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConShape
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char repeat;

            do
            {
                Shape shape = null;

                Console.WriteLine("Select a Shape to Calculate Area:");
                Console.WriteLine("1. Circle");
                Console.WriteLine("2. Square");
                Console.WriteLine("3. Rectangle");
                Console.WriteLine("4. Other Shape");
                Console.Write("Enter your choice: ");

                int choice = int.Parse(Console.ReadLine());

                Console.Write("Enter name: ");
                string name = Console.ReadLine();

                Console.Write("Enter color: ");
                string color = Console.ReadLine();

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter radius: ");
                        double radius = double.Parse(Console.ReadLine());
                        shape = new Circle(name, color, 0, radius);
                        break;

                    case 2:
                        Console.Write("Enter side length: ");
                        double side = double.Parse(Console.ReadLine());
                        shape = new Square(name, color, 4, side);
                        break;

                    case 3:
                        Console.Write("Enter length: ");
                        double length = double.Parse(Console.ReadLine());

                        Console.Write("Enter width: ");
                        double width = double.Parse(Console.ReadLine());
                        shape = new Rectangle(name, color, 4, length, width);
                        break;

                    case 4:
                        Console.Write("Enter number of sides: ");
                        int sides = int.Parse(Console.ReadLine());
                        shape = new Shape(name, color, sides);
                        break;

                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }

                if (shape != null)
                {
                    Console.WriteLine("\n--- Shape Details ---");
                    Console.WriteLine(shape);
                }

                Console.Write("\nDo you want to enter another shape? (y/n): ");
                repeat = char.ToLower(Console.ReadKey().KeyChar);
                Console.WriteLine("\n");

            } while (repeat == 'y');

            Console.WriteLine("Program ended. Goodbye!");
            Console.ReadLine();
        }
    }
}
