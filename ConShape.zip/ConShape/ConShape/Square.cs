﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConShape
{
    internal class Square:Shape
    {
        public double sideLength;

        public double SideLength { get => sideLength; set => sideLength = value; }

        public Square(string name, string color, int noSide, double sideLength)
        {
            base.Name = name;
            base.Color = color;
            base.NoSide = noSide;
            this.SideLength = sideLength;
        }

        public override string ToString()
        {
            return "\nName: " + base.Name +
                "\nColor: " + base.Color +
                "\n No of Side: " + base.NoSide +
                "\n Length of one side: "+this.SideLength +
                "\nArea of a Square: " + ComputeArea();
        }

        public override double ComputeArea()
        {
            return Math.Pow(this.sideLength, 2);
        }
    }

}
