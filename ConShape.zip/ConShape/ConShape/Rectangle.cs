﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConShape
{
    internal class Rectangle:Shape
    {

        private double length;
        private double width;

        public double Length { get => length; set => length = value; }
        public double Width { get => width; set => width = value; }


        public Rectangle (string name, string color, int noSide, double length, double width)
        {
            base.Name = name;
            base.Color = color;
            base.NoSide = noSide;
            this.Length = length;
            this.Width = width;
        }
        public override string ToString()
        {
            return "\nName: " + this.Name + "\nColor" + this.Color +
                "\n No of Side: " + this.NoSide + 
                "\nLenght of Rectangle: "+this.length+
                "\nWidth of Rectangle: "+this.width+ 
                "\nArea of a Rectangle: " + ComputeArea();
        }

        public override double ComputeArea()
        {
            return Math.Pow(this.length, 2)* this.width;
        }
    }
}
